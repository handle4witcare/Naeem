# Naeem — AI Movie & Scene Studio

A complete, **launchable** browser-based website for creating, structuring, and preparing animated movies and scenes with AI.

No backend, no accounts, no API keys required. Everything runs locally in your browser and saves projects to localStorage.

## Features

- **15-minute hard limit**: No project can exceed 15 minutes total runtime. The app blocks or auto-caps any duration that would go over.
- **5-minute per-scene limit**: Individual shots/scenes cannot exceed 5 minutes.
- **Optional encryption**: AES-256-GCM with PBKDF2-derived keys (250k iterations). Fresh random IV on every save so ciphertext changes frequently; passphrase rotation regenerates salt/key material. Enable via the 🔒 button.
- **Idea → Structure**: Paste a short description or script. Naeem expands it into a multi-shot outline with camera suggestions and durations (capped at 15 min).
- **Storyboard editor**: Edit each shot’s description, camera move, duration, and notes.
- **Character consistency**: Define characters once; their descriptions are injected into every generated prompt so AI video tools keep identity consistent.
- **Timeline**: Visual overview of shot order, remaining time, and total runtime. Drag to reorder.
- **Prompt export**: One-click, model-tuned prompts ready for:
  - Kling AI
  - Runway
  - Seedance / Dreamina
  - Pika
  - Google Veo
  - or generic / universal
- **Preview**: Timed storyboard player — step through or auto-play shots with a progress bar.
- **Download**: Export as JSON project, prompts TXT, storyboard HTML (print to PDF), or CSV shot list.
- **Project library**: Create, open, delete, and export projects as JSON.
- **Dark / light theme**
- **Fully responsive** (works on iPhone / iPad)

## How to launch

### Option 1 — Open locally (fastest)
1. Download or copy the entire app folder.
2. Open `index.html` in any modern browser (Chrome, Safari, Firefox, Edge).

### Option 2 — Local server (recommended for development)
```bash
cd cineforge
python3 -m http.server 8080
```
Then visit http://localhost:8080

### Option 3 — Deploy anywhere
Upload the folder to Netlify, Vercel, GitHub Pages, Cloudflare Pages, or any static host. No build step needed.

## Typical workflow

1. Click **Start Creating** or **+ New Project**.
2. Write your idea in the **Idea & Script** tab (example included in the placeholder).
3. Choose a visual style and aspect ratio in the sidebar.
4. Click **Generate Structure with AI** → shots appear in the Storyboard.
5. Refine descriptions, camera notes, and durations.
6. Add characters if you need consistent appearance across shots.
7. Go to the **Prompts** tab, pick your target AI model, and copy each prompt.
8. Use **Preview** to play through the timed storyboard.
9. Use **Download** to export JSON, prompts, storyboard HTML, or CSV.
10. Paste prompts into your preferred AI video tool and assemble the clips.

## File structure

```
cineforge/
├── index.html
├── css/styles.css
├── js/app.js
└── README.md
```

## Notes

- **Hard limit of 15 minutes** total runtime per project; **5 minutes** max per scene.
- This is a **planning & prompt-generation** studio, not a full text-to-video model. It produces high-quality, structured prompts that dramatically improve results from real AI video generators.
- All data stays on your device (localStorage). Clearing browser data will remove projects.
- No external AI calls are made — generation is deterministic and instant after the short simulated “thinking” delay.

Enjoy creating with **Naeem**.
