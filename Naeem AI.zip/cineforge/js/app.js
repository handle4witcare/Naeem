/**
 * Naeem — AI Movie & Scene Studio
 * Self-contained browser app for AI-assisted film creation.
 */

const App = (() => {
  // ---------- State ----------
  let projects = [];
  let currentProject = null;
  let editingCharId = null;

  // Hard limit: no project may exceed 15 minutes total
  const MAX_DURATION_SECONDS = 15 * 60; // 900
  // Per-scene / per-shot maximum duration
  const MAX_SHOT_SECONDS = 5 * 60; // 5 minutes

  // ---------- Storage ----------
  const STORAGE_KEY = 'naeem_projects_v1';
  const ENC_STORAGE_KEY = 'naeem_projects_enc_v1';
  const SALT_KEY = 'naeem_salt_v1';
  const IV_KEY = 'naeem_iv_meta_v1';

  // Session encryption state (never persisted as plaintext key material)
  let sessionPassphrase = null;
  let cryptoKey = null;
  let encryptionEnabled = false;

  // --- Web Crypto helpers (AES-GCM + PBKDF2) ---
  function bufToB64(buf) {
    return btoa(String.fromCharCode(...new Uint8Array(buf)));
  }
  function b64ToBuf(b64) {
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return arr.buffer;
  }

  async function deriveKey(passphrase, salt) {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      'raw', enc.encode(passphrase), 'PBKDF2', false, ['deriveKey']
    );
    // High iteration count; salt is random and stored separately
    return crypto.subtle.deriveKey(
      { name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  async function encryptData(plaintext, key) {
    const iv = crypto.getRandomValues(new Uint8Array(12)); // fresh IV every encrypt
    const enc = new TextEncoder();
    const ciphertext = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      enc.encode(plaintext)
    );
    return { iv: bufToB64(iv), data: bufToB64(ciphertext) };
  }

  async function decryptData(payload, key) {
    const iv = b64ToBuf(payload.iv);
    const data = b64ToBuf(payload.data);
    const dec = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: new Uint8Array(iv) },
      key,
      data
    );
    return new TextDecoder().decode(dec);
  }

  function getOrCreateSalt() {
    let saltB64 = localStorage.getItem(SALT_KEY);
    if (!saltB64) {
      const salt = crypto.getRandomValues(new Uint8Array(16));
      saltB64 = bufToB64(salt);
      localStorage.setItem(SALT_KEY, saltB64);
    }
    return b64ToBuf(saltB64);
  }

  async function enableEncryption(passphrase) {
    if (!passphrase || passphrase.length < 8) {
      showToast('Passphrase must be at least 8 characters');
      return false;
    }
    try {
      const salt = getOrCreateSalt();
      cryptoKey = await deriveKey(passphrase, salt);
      sessionPassphrase = passphrase;
      encryptionEnabled = true;
      // Immediately re-save with encryption (new IV each time)
      await saveProjectsSecure();
      showToast('Encryption enabled — data is protected');
      return true;
    } catch (e) {
      console.error(e);
      showToast('Failed to enable encryption');
      return false;
    }
  }

  async function changePassphrase(oldPass, newPass) {
    if (!encryptionEnabled) {
      showToast('Enable encryption first');
      return false;
    }
    if (!newPass || newPass.length < 8) {
      showToast('New passphrase must be at least 8 characters');
      return false;
    }
    // Verify old by attempting decrypt of current store if present
    try {
      const salt = getOrCreateSalt();
      const testKey = await deriveKey(oldPass, salt);
      // If we have encrypted data, try decrypt
      const encRaw = localStorage.getItem(ENC_STORAGE_KEY);
      if (encRaw) {
        await decryptData(JSON.parse(encRaw), testKey);
      }
      // Rotate salt for key rotation ("keys that change")
      const newSalt = crypto.getRandomValues(new Uint8Array(16));
      localStorage.setItem(SALT_KEY, bufToB64(newSalt));
      cryptoKey = await deriveKey(newPass, newSalt);
      sessionPassphrase = newPass;
      await saveProjectsSecure();
      showToast('Passphrase changed — keys rotated');
      return true;
    } catch {
      showToast('Old passphrase incorrect');
      return false;
    }
  }

  async function unlockWithPassphrase(passphrase) {
    try {
      const salt = getOrCreateSalt();
      const key = await deriveKey(passphrase, salt);
      const encRaw = localStorage.getItem(ENC_STORAGE_KEY);
      if (encRaw) {
        const plain = await decryptData(JSON.parse(encRaw), key);
        projects = JSON.parse(plain);
      } else {
        // Migrate plaintext if present
        const plainRaw = localStorage.getItem(STORAGE_KEY);
        projects = plainRaw ? JSON.parse(plainRaw) : [];
      }
      cryptoKey = key;
      sessionPassphrase = passphrase;
      encryptionEnabled = true;
      await saveProjectsSecure();
      // Clear old plaintext after successful migration
      localStorage.removeItem(STORAGE_KEY);
      return true;
    } catch {
      projects = [];
      return false;
    }
  }

  async function saveProjectsSecure() {
    if (encryptionEnabled && cryptoKey) {
      // Fresh random IV on every save — ciphertext changes even if data is identical
      const payload = await encryptData(JSON.stringify(projects), cryptoKey);
      localStorage.setItem(ENC_STORAGE_KEY, JSON.stringify(payload));
      localStorage.removeItem(STORAGE_KEY); // never keep plaintext when encrypted
    } else {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
    }
  }

  function loadProjects() {
    // Synchronous fallback for initial paint; full unlock may be async
    try {
      const encRaw = localStorage.getItem(ENC_STORAGE_KEY);
      if (encRaw) {
        // Encrypted store exists — leave locked until user unlocks
        projects = [];
        encryptionEnabled = true; // flag that lock is needed
        return;
      }
      const raw = localStorage.getItem(STORAGE_KEY);
      projects = raw ? JSON.parse(raw) : [];
    } catch {
      projects = [];
    }
  }

  function saveProjects() {
    // Fire-and-forget async secure save
    saveProjectsSecure().catch(err => console.error('Save failed', err));
  }

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function getTotalDuration(shots) {
    if (!shots || !shots.length) return 0;
    return shots.reduce((sum, s) => sum + (Number(s.duration) || 0), 0);
  }

  function formatDuration(seconds) {
    const s = Math.max(0, Math.round(seconds));
    if (s < 60) return s + 's';
    const m = Math.floor(s / 60);
    const rem = s % 60;
    return rem ? `${m}m ${rem}s` : `${m}m`;
  }

  // ---------- AI Simulation Helpers ----------
  // These produce structured, useful output from user input without external APIs.
  // Users then take the generated prompts into real AI video tools.

  function extractKeywords(text) {
    const lower = text.toLowerCase();
    const styles = [];
    if (/pixar|3d|cgi|cartoon/.test(lower)) styles.push('3D Pixar-style');
    if (/anime|manga/.test(lower)) styles.push('anime');
    if (/noir|black.?white|detective/.test(lower)) styles.push('film noir');
    if (/sci-?fi|robot|space|cyber/.test(lower)) styles.push('sci-fi');
    if (/fantasy|dragon|magic|elf/.test(lower)) styles.push('fantasy');
    if (/warm|hopeful|gentle|tender/.test(lower)) styles.push('warm and emotional');
    if (/dark|grim|dystopia|ruined/.test(lower)) styles.push('moody and atmospheric');
    return styles.length ? styles.join(', ') : 'cinematic';
  }

  function generateOutlineFromIdea(idea, style) {
    const sentences = idea.split(/[.!?]+/).map(s => s.trim()).filter(Boolean);
    const mainIdea = sentences[0] || idea.slice(0, 120);

    // Simple scene detection
    const sceneHints = [];
    if (/day|morning|sunrise|dawn/.test(idea.toLowerCase())) sceneHints.push('day');
    if (/night|evening|sunset|dusk/.test(idea.toLowerCase())) sceneHints.push('night');
    if (/rain|storm|acid/.test(idea.toLowerCase())) sceneHints.push('rain');
    if (/garden|flower|plant/.test(idea.toLowerCase())) sceneHints.push('garden');
    if (/city|street|ruin|building/.test(idea.toLowerCase())) sceneHints.push('city');
    if (/robot|machine|android/.test(idea.toLowerCase())) sceneHints.push('robot');

    let duration = /second|sec|minute|min/.test(idea.toLowerCase())
      ? (Number(idea.match(/(\d+)\s*(?:second|sec)/i)?.[1]) || Number(idea.match(/(\d+)\s*(?:minute|min)/i)?.[1]) * 60 || 30)
      : 30;

    // Enforce 15-minute hard limit
    if (duration > MAX_DURATION_SECONDS) {
      duration = MAX_DURATION_SECONDS;
    }

    // Build 3–6 shots depending on length of idea (more shots for longer pieces, still capped)
    const numShots = Math.min(12, Math.max(3, Math.ceil(sentences.length / 1.2) || 4));

    const shots = [];
    const templates = [
      { cam: 'Wide establishing shot', action: 'Introduce the world and mood' },
      { cam: 'Medium shot', action: 'Introduce the main character' },
      { cam: 'Close-up', action: 'Focus on the key object or emotion' },
      { cam: 'Tracking shot', action: 'Follow the action or discovery' },
      { cam: 'Over-the-shoulder / reaction', action: 'Show reaction or decision' },
      { cam: 'Wide closing shot', action: 'Resolve the story and leave an emotion' }
    ];

    for (let i = 0; i < numShots; i++) {
      const t = templates[i % templates.length];
      const dur = Math.round(duration / numShots);
      shots.push({
        id: uid(),
        number: i + 1,
        title: `Shot ${i + 1}`,
        description: `${t.action}. ${mainIdea.slice(0, 80)}${mainIdea.length > 80 ? '…' : ''}`,
        camera: t.cam,
        duration: dur,
        prompt: '',
        notes: ''
      });
    }

    // Refine first and last
    if (shots[0]) {
      shots[0].description = `Opening: establish the setting and tone. ${mainIdea}`;
      shots[0].camera = 'Wide establishing shot, slow push-in';
    }
    if (shots.length > 1) {
      shots[shots.length - 1].description = `Closing: emotional resolution or final image. Leave a lasting feeling.`;
      shots[shots.length - 1].camera = 'Wide or medium closing shot, gentle pull-back or hold';
    }

    return {
      summary: mainIdea,
      styleNote: extractKeywords(idea) || style,
      estimatedDuration: duration,
      shots
    };
  }

  function buildPrompt(shot, project, model = 'general') {
    const styleMap = {
      cinematic: 'photoreal cinematic lighting, film grain, shallow depth of field, 35mm',
      pixar: 'Pixar-style 3D animation, soft lighting, expressive characters, vibrant but warm colors',
      anime: 'high-quality anime, detailed backgrounds, cinematic anime lighting, Studio Ghibli influence',
      '2d': 'clean 2D flat animation, bold outlines, limited color palette, stylized',
      noir: 'black and white film noir, high contrast, dramatic shadows, 1940s aesthetic',
      fantasy: 'epic fantasy, volumetric god rays, detailed environments, magical atmosphere',
      scifi: 'sci-fi, neon accents, futuristic design, atmospheric haze, cinematic',
      documentary: 'documentary style, natural lighting, handheld feel, authentic'
    };

    const styleDesc = styleMap[project.style] || styleMap.cinematic;
    const aspect = project.aspect || '16:9';

    let chars = '';
    if (project.characters && project.characters.length) {
      chars = project.characters.map(c => `${c.name}: ${c.description}`).join('; ');
    }

    const base = [
      shot.description,
      shot.camera ? `Camera: ${shot.camera}` : '',
      chars ? `Characters: ${chars}` : '',
      `Visual style: ${styleDesc}`,
      `Aspect ratio ${aspect}`,
      shot.notes || ''
    ].filter(Boolean).join('. ');

    // Model-specific flavor
    const modelHints = {
      kling: 'High motion quality, natural character movement, consistent identity across frames.',
      runway: 'Cinematic camera move, high detail, coherent motion.',
      seedance: 'Smooth continuous motion, strong temporal consistency, detailed environments.',
      pika: 'Dynamic movement, stylized, energetic.',
      veo: 'Photoreal or high cinematic quality, natural physics, long coherent shot.',
      general: ''
    };

    return `${base}. ${modelHints[model] || ''}`.replace(/\s+/g, ' ').trim();
  }

  // ---------- Project CRUD ----------
  function createProject() {
    const p = {
      id: uid(),
      title: 'Untitled Film',
      style: 'cinematic',
      aspect: '16:9',
      idea: '',
      characters: [],
      shots: [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    projects.unshift(p);
    saveProjects();
    openProject(p.id);
    showToast('New project created');
  }

  function openProject(id) {
    currentProject = projects.find(p => p.id === id);
    if (!currentProject) return;
    document.getElementById('nav-studio').style.display = 'inline-block';
    showView('studio');
    renderStudio();
  }

  function saveProject() {
    if (!currentProject) return;
    // pull from UI
    currentProject.title = document.getElementById('project-title').value || 'Untitled Film';
    currentProject.style = document.getElementById('project-style').value;
    currentProject.aspect = document.getElementById('project-aspect').value;
    currentProject.idea = document.getElementById('idea-input').value;
    currentProject.updatedAt = Date.now();

    // sync shots from DOM if needed (already mutated in place)
    const idx = projects.findIndex(p => p.id === currentProject.id);
    if (idx >= 0) projects[idx] = currentProject;
    saveProjects();
    showToast('Project saved');
  }

  function deleteProject(id) {
    if (!confirm('Delete this project permanently?')) return;
    projects = projects.filter(p => p.id !== id);
    saveProjects();
    if (currentProject && currentProject.id === id) {
      currentProject = null;
      showView('library');
    }
    renderLibrary();
    showToast('Project deleted');
  }

  // ---------- Characters ----------
  function addCharacter() {
    editingCharId = null;
    document.getElementById('char-modal-title').textContent = 'Add Character';
    document.getElementById('char-name').value = '';
    document.getElementById('char-desc').value = '';
    document.getElementById('char-role').value = '';
    document.getElementById('modal-character').style.display = 'flex';
  }

  function editCharacter(id) {
    const c = currentProject.characters.find(ch => ch.id === id);
    if (!c) return;
    editingCharId = id;
    document.getElementById('char-modal-title').textContent = 'Edit Character';
    document.getElementById('char-name').value = c.name;
    document.getElementById('char-desc').value = c.description;
    document.getElementById('char-role').value = c.role || '';
    document.getElementById('modal-character').style.display = 'flex';
  }

  function saveCharacter() {
    const name = document.getElementById('char-name').value.trim();
    const description = document.getElementById('char-desc').value.trim();
    const role = document.getElementById('char-role').value.trim();
    if (!name) {
      showToast('Name is required');
      return;
    }
    if (editingCharId) {
      const c = currentProject.characters.find(ch => ch.id === editingCharId);
      if (c) {
        c.name = name;
        c.description = description;
        c.role = role;
      }
    } else {
      currentProject.characters.push({ id: uid(), name, description, role });
    }
    closeModal();
    renderCharacters();
    saveProject();
  }

  function removeCharacter(id) {
    currentProject.characters = currentProject.characters.filter(c => c.id !== id);
    renderCharacters();
    saveProject();
  }

  function closeModal() {
    document.getElementById('modal-character').style.display = 'none';
  }

  // ---------- Shots ----------
  function addShot() {
    if (!currentProject) return;
    const currentTotal = getTotalDuration(currentProject.shots);
    if (currentTotal >= MAX_DURATION_SECONDS) {
      showToast('15-minute limit reached. Shorten existing shots first.');
      return;
    }
    const remaining = MAX_DURATION_SECONDS - currentTotal;
    const defaultDur = Math.min(5, remaining);
    const n = currentProject.shots.length + 1;
    currentProject.shots.push({
      id: uid(),
      number: n,
      title: `Shot ${n}`,
      description: '',
      camera: 'Medium shot',
      duration: defaultDur,
      prompt: '',
      notes: ''
    });
    renderStoryboard();
    renderTimeline();
    saveProject();
  }

  function removeShot(id) {
    currentProject.shots = currentProject.shots.filter(s => s.id !== id);
    // renumber
    currentProject.shots.forEach((s, i) => { s.number = i + 1; s.title = s.title.replace(/^Shot \d+/, `Shot ${i + 1}`); });
    renderStoryboard();
    renderTimeline();
    refreshPrompts();
    saveProject();
  }

  function updateShot(id, field, value) {
    const s = currentProject.shots.find(sh => sh.id === id);
    if (!s) return;

    if (field === 'duration') {
      // Per-scene max = 5 minutes; also respect total 15-min project limit
      let newDur = Math.max(1, Math.min(MAX_SHOT_SECONDS, Number(value) || 1));
      if (Number(value) > MAX_SHOT_SECONDS) {
        showToast(`Per-scene limit is 5 minutes (${MAX_SHOT_SECONDS}s).`);
      }
      const otherTotal = getTotalDuration(currentProject.shots.filter(sh => sh.id !== id));
      const maxAllowed = MAX_DURATION_SECONDS - otherTotal;
      if (newDur > maxAllowed) {
        newDur = Math.max(1, maxAllowed);
        showToast(`Duration capped — total cannot exceed 15 minutes (${formatDuration(MAX_DURATION_SECONDS)}).`);
      }
      s.duration = newDur;
      renderTimeline();
      renderStoryboard(); // refresh the input value if it was capped
    } else {
      s[field] = value;
    }

    // live update prompt text if visible
    if (document.querySelector('.tab[data-tab="prompts"].active')) {
      refreshPrompts();
    }
  }

  // ---------- Generate Structure ----------
  function generateStructure() {
    const idea = document.getElementById('idea-input').value.trim();
    if (!idea) {
      showToast('Please write an idea or script first');
      return;
    }
    const btn = document.getElementById('generate-structure-btn');
    btn.querySelector('.btn-text').style.display = 'none';
    btn.querySelector('.btn-loader').style.display = 'inline';
    btn.disabled = true;

    // Simulate AI thinking
    setTimeout(() => {
      const style = document.getElementById('project-style').value;
      const result = generateOutlineFromIdea(idea, style);

      currentProject.idea = idea;
      let shots = result.shots.map(s => ({
        ...s,
        prompt: buildPrompt(s, currentProject, 'general')
      }));

      // Final safety: scale durations if total somehow exceeds limit
      let total = getTotalDuration(shots);
      if (total > MAX_DURATION_SECONDS) {
        const scale = MAX_DURATION_SECONDS / total;
        shots = shots.map(s => ({
          ...s,
          duration: Math.max(1, Math.round(s.duration * scale))
        }));
        total = getTotalDuration(shots);
        showToast('Duration reduced to stay within 15-minute limit');
      }
      currentProject.shots = shots;

      // Show outline
      const preview = document.getElementById('script-preview');
      const content = document.getElementById('script-content');
      content.textContent =
        `Summary: ${result.summary}\n\n` +
        `Style direction: ${result.styleNote}\n` +
        `Estimated runtime: ~${formatDuration(total)} (max 15 min)\n\n` +
        `Shots generated: ${shots.length}\n\n` +
        shots.map(s => `${s.number}. [${s.camera}] ${s.description} (${s.duration}s)`).join('\n\n');
      preview.style.display = 'block';

      renderStoryboard();
      renderTimeline();
      refreshPrompts();
      saveProject();

      btn.querySelector('.btn-text').style.display = 'inline';
      btn.querySelector('.btn-loader').style.display = 'none';
      btn.disabled = false;
      showToast(`Generated ${result.shots.length} shots`);
      // switch to storyboard
      switchTab('storyboard');
    }, 900 + Math.random() * 600);
  }

  // ---------- Render ----------
  function renderStudio() {
    if (!currentProject) return;
    document.getElementById('project-title').value = currentProject.title;
    document.getElementById('project-style').value = currentProject.style;
    document.getElementById('project-aspect').value = currentProject.aspect;
    document.getElementById('idea-input').value = currentProject.idea || '';
    renderCharacters();
    renderStoryboard();
    renderTimeline();
    refreshPrompts();
  }

  function renderCharacters() {
    const list = document.getElementById('character-list');
    if (!currentProject.characters.length) {
      list.innerHTML = '<p class="muted" style="font-size:0.8rem">No characters yet</p>';
      return;
    }
    list.innerHTML = currentProject.characters.map(c => `
      <div class="char-item">
        <span class="name">${escapeHtml(c.name)}</span>
        <div class="actions">
          <button onclick="App.editCharacter('${c.id}')" title="Edit">✎</button>
          <button onclick="App.removeCharacter('${c.id}')" title="Remove">×</button>
        </div>
      </div>
    `).join('');
  }

  function renderStoryboard() {
    const list = document.getElementById('storyboard-list');
    if (!currentProject.shots.length) {
      list.innerHTML = `
        <div class="empty-state">
          <p>No shots yet. Generate structure from your idea or add shots manually.</p>
          <button class="btn btn-primary" onclick="App.addShot()">+ Add Shot</button>
        </div>`;
      return;
    }
    list.innerHTML = currentProject.shots.map(s => `
      <div class="shot-card" data-id="${s.id}">
        <div class="shot-num">${s.number}</div>
        <div class="shot-body">
          <input class="input" value="${escapeHtml(s.title)}" 
            onchange="App.updateShot('${s.id}','title',this.value)" placeholder="Shot title" />
          <textarea class="textarea" rows="2" 
            onchange="App.updateShot('${s.id}','description',this.value)"
            placeholder="What happens in this shot…">${escapeHtml(s.description)}</textarea>
          <div class="shot-row">
            <div>
              <label class="label">Camera</label>
              <input class="input" value="${escapeHtml(s.camera)}" 
                onchange="App.updateShot('${s.id}','camera',this.value)" />
            </div>
            <div>
              <label class="label">Duration (sec)</label>
              <input class="input" type="number" min="1" max="300" value="${s.duration}" 
                onchange="App.updateShot('${s.id}','duration',parseInt(this.value)||5)" />
            </div>
          </div>
          <div>
            <label class="label">Notes</label>
            <input class="input" value="${escapeHtml(s.notes || '')}" 
              onchange="App.updateShot('${s.id}','notes',this.value)" placeholder="Optional notes" />
          </div>
          <div class="shot-actions">
            <button class="btn btn-ghost btn-sm" onclick="App.removeShot('${s.id}')">Delete</button>
          </div>
        </div>
      </div>
    `).join('');
  }

  function renderTimeline() {
    const track = document.getElementById('timeline-track');
    const totalEl = document.getElementById('total-duration');
    if (!currentProject.shots.length) {
      track.innerHTML = '<p class="muted">Add shots to see the timeline</p>';
      totalEl.innerHTML = `0s <span class="limit-label">/ 15 min max</span>`;
      return;
    }
    const total = getTotalDuration(currentProject.shots);
    const remaining = Math.max(0, MAX_DURATION_SECONDS - total);
    const overLimit = total > MAX_DURATION_SECONDS;

    track.innerHTML = currentProject.shots.map(s => {
      return `
        <div class="timeline-clip" draggable="true" data-id="${s.id}">
          <div class="clip-info">
            <strong>${s.number}. ${escapeHtml(s.title)}</strong>
            <div class="muted" style="font-size:0.8rem;margin-top:2px">${escapeHtml(s.camera)}</div>
          </div>
          <span class="clip-dur">${s.duration}s</span>
        </div>`;
    }).join('');

    totalEl.innerHTML = `
      <span class="${overLimit ? 'over-limit' : ''}">${formatDuration(total)}</span>
      <span class="limit-label">/ 15 min max</span>
      ${remaining > 0 && remaining < MAX_DURATION_SECONDS ? `<span class="remaining">(${formatDuration(remaining)} left)</span>` : ''}
      ${overLimit ? `<span class="over-limit-msg">Over limit — shorten shots</span>` : ''}
    `;

    // simple drag reorder
    const clips = track.querySelectorAll('.timeline-clip');
    let dragId = null;
    clips.forEach(clip => {
      clip.addEventListener('dragstart', e => {
        dragId = clip.dataset.id;
        e.dataTransfer.effectAllowed = 'move';
      });
      clip.addEventListener('dragover', e => e.preventDefault());
      clip.addEventListener('drop', e => {
        e.preventDefault();
        const targetId = clip.dataset.id;
        if (!dragId || dragId === targetId) return;
        const from = currentProject.shots.findIndex(s => s.id === dragId);
        const to = currentProject.shots.findIndex(s => s.id === targetId);
        if (from < 0 || to < 0) return;
        const [item] = currentProject.shots.splice(from, 1);
        currentProject.shots.splice(to, 0, item);
        currentProject.shots.forEach((s, i) => { s.number = i + 1; s.title = s.title.replace(/^Shot \d+/, `Shot ${i + 1}`); });
        renderTimeline();
        renderStoryboard();
        refreshPrompts();
        saveProject();
      });
    });
  }

  function refreshPrompts() {
    const list = document.getElementById('prompt-list');
    const model = document.getElementById('prompt-model').value;
    if (!currentProject || !currentProject.shots.length) {
      list.innerHTML = '<p class="muted">Generate or add shots first</p>';
      return;
    }
    list.innerHTML = currentProject.shots.map(s => {
      const prompt = buildPrompt(s, currentProject, model);
      s.prompt = prompt; // keep updated
      return `
        <div class="prompt-card">
          <div class="prompt-header">
            <h4>Shot ${s.number} — ${escapeHtml(s.title)}</h4>
            <button class="btn btn-ghost copy-btn" onclick="App.copyText(\`${escapeForAttr(prompt)}\`)">Copy</button>
          </div>
          <div class="prompt-text">${escapeHtml(prompt)}</div>
        </div>`;
    }).join('');
  }

  function renderLibrary() {
    const list = document.getElementById('project-list');
    const empty = document.getElementById('empty-library');
    if (!projects.length) {
      list.innerHTML = '';
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';
    list.innerHTML = projects.map(p => {
      const date = new Date(p.updatedAt || p.createdAt).toLocaleDateString();
      const shotCount = (p.shots || []).length;
      return `
        <div class="project-card" onclick="App.openProject('${p.id}')">
          <h3>${escapeHtml(p.title)}</h3>
          <div class="meta">${shotCount} shot${shotCount !== 1 ? 's' : ''} · ${escapeHtml(p.style)} · ${date}</div>
          <div class="actions" onclick="event.stopPropagation()">
            <button class="btn btn-ghost btn-sm" onclick="App.openProject('${p.id}')">Open</button>
            <button class="btn btn-ghost btn-sm" onclick="App.deleteProject('${p.id}')">Delete</button>
          </div>
        </div>`;
    }).join('');
  }

  // ---------- Preview state ----------
  let previewIndex = 0;
  let previewPlaying = false;
  let previewTimer = null;
  let previewElapsedInShot = 0;
  let previewRaf = null;

  function safeFilename(name) {
    return (name || 'naeem-project').replace(/[^\w\s-]/g, '').replace(/\s+/g, '-').toLowerCase().slice(0, 60) || 'naeem-project';
  }

  function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  // ---------- Export / Download ----------
  function exportProject() {
    downloadJSON();
  }

  function downloadJSON() {
    if (!currentProject) return;
    saveProject();
    const model = document.getElementById('prompt-model')?.value || 'general';
    const data = {
      ...currentProject,
      exportedAt: new Date().toISOString(),
      prompts: currentProject.shots.map(s => ({
        shot: s.number,
        title: s.title,
        duration: s.duration,
        prompt: buildPrompt(s, currentProject, model)
      }))
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    triggerDownload(blob, `${safeFilename(currentProject.title)}.json`);
    showToast('JSON downloaded');
  }

  function downloadPrompts() {
    if (!currentProject || !currentProject.shots.length) {
      showToast('No shots to export');
      return;
    }
    saveProject();
    const model = document.getElementById('prompt-model')?.value || 'general';
    const lines = [
      `Naeem — Prompts for "${currentProject.title}"`,
      `Style: ${currentProject.style} | Aspect: ${currentProject.aspect} | Model: ${model}`,
      `Exported: ${new Date().toISOString()}`,
      `Total shots: ${currentProject.shots.length} | Total duration: ${formatDuration(getTotalDuration(currentProject.shots))}`,
      '',
      '─'.repeat(40)
    ];
    currentProject.shots.forEach(s => {
      lines.push('');
      lines.push(`SHOT ${s.number}: ${s.title} (${s.duration}s)`);
      lines.push(`Camera: ${s.camera || '—'}`);
      lines.push(`Description: ${s.description || '—'}`);
      lines.push('');
      lines.push('PROMPT:');
      lines.push(buildPrompt(s, currentProject, model));
      lines.push('');
      lines.push('─'.repeat(40));
    });
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    triggerDownload(blob, `${safeFilename(currentProject.title)}-prompts.txt`);
    showToast('Prompts downloaded');
  }

  function downloadCSV() {
    if (!currentProject || !currentProject.shots.length) {
      showToast('No shots to export');
      return;
    }
    saveProject();
    const model = document.getElementById('prompt-model')?.value || 'general';
    const escapeCsv = (v) => {
      const s = String(v ?? '');
      if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
      return s;
    };
    const rows = [
      ['Shot', 'Title', 'Duration (s)', 'Camera', 'Description', 'Notes', 'Prompt'].map(escapeCsv).join(',')
    ];
    currentProject.shots.forEach(s => {
      rows.push([
        s.number,
        s.title,
        s.duration,
        s.camera,
        s.description,
        s.notes,
        buildPrompt(s, currentProject, model)
      ].map(escapeCsv).join(','));
    });
    const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8' });
    triggerDownload(blob, `${safeFilename(currentProject.title)}-shots.csv`);
    showToast('CSV downloaded');
  }

  function downloadStoryboard() {
    if (!currentProject) return;
    saveProject();
    const model = document.getElementById('prompt-model')?.value || 'general';
    const total = getTotalDuration(currentProject.shots);
    const chars = (currentProject.characters || []).map(c =>
      `<li><strong>${escapeHtml(c.name)}</strong> — ${escapeHtml(c.description || '')}</li>`
    ).join('') || '<li>None defined</li>';

    const shotsHtml = (currentProject.shots || []).map(s => `
      <div class="shot">
        <div class="shot-head">
          <span class="num">Shot ${s.number}</span>
          <span class="dur">${s.duration}s</span>
        </div>
        <h3>${escapeHtml(s.title)}</h3>
        <p class="cam">${escapeHtml(s.camera || '')}</p>
        <p>${escapeHtml(s.description || '')}</p>
        ${s.notes ? `<p class="notes"><em>Notes:</em> ${escapeHtml(s.notes)}</p>` : ''}
        <details>
          <summary>AI Prompt</summary>
          <pre>${escapeHtml(buildPrompt(s, currentProject, model))}</pre>
        </details>
      </div>
    `).join('');

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${escapeHtml(currentProject.title)} — Storyboard</title>
<style>
  body { font-family: system-ui, -apple-system, sans-serif; max-width: 800px; margin: 2rem auto; padding: 0 1rem; color: #111; line-height: 1.5; }
  h1 { margin-bottom: 0.25rem; }
  .meta { color: #555; margin-bottom: 1.5rem; }
  .shot { border: 1px solid #ddd; border-radius: 10px; padding: 1rem 1.2rem; margin-bottom: 1rem; page-break-inside: avoid; }
  .shot-head { display: flex; justify-content: space-between; font-size: 0.85rem; color: #666; margin-bottom: 0.35rem; }
  .num { font-weight: 700; color: #5b3ae0; }
  .cam { font-family: ui-monospace, monospace; font-size: 0.85rem; color: #666; }
  pre { white-space: pre-wrap; background: #f6f6f8; padding: 0.75rem; border-radius: 6px; font-size: 0.8rem; }
  details { margin-top: 0.5rem; }
  @media print { body { margin: 0; } .shot { break-inside: avoid; } }
</style>
</head>
<body>
  <h1>${escapeHtml(currentProject.title)}</h1>
  <p class="meta">
    Style: ${escapeHtml(currentProject.style)} · Aspect: ${escapeHtml(currentProject.aspect)} ·
    ${currentProject.shots.length} shots · ${formatDuration(total)} total ·
    Exported ${new Date().toLocaleString()}
  </p>
  <h2>Characters</h2>
  <ul>${chars}</ul>
  <h2>Storyboard</h2>
  ${shotsHtml || '<p>No shots yet.</p>'}
  <p style="margin-top:2rem;color:#888;font-size:0.85rem">Generated with Naeem</p>
</body>
</html>`;

    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    triggerDownload(blob, `${safeFilename(currentProject.title)}-storyboard.html`);
    showToast('Storyboard HTML downloaded — open it or Print → Save as PDF');
  }

  // ---------- Preview player ----------
  function formatClock(sec) {
    const s = Math.max(0, Math.floor(sec));
    const m = Math.floor(s / 60);
    const r = s % 60;
    return `${m}:${String(r).padStart(2, '0')}`;
  }

  function showPreviewShot(index) {
    if (!currentProject || !currentProject.shots.length) return;
    const shots = currentProject.shots;
    previewIndex = Math.max(0, Math.min(index, shots.length - 1));
    const s = shots[previewIndex];

    document.getElementById('preview-placeholder').style.display = 'none';
    const content = document.getElementById('preview-content');
    content.style.display = 'block';
    // re-trigger animation
    content.style.animation = 'none';
    void content.offsetWidth;
    content.style.animation = '';

    document.getElementById('preview-shot-num').textContent = `Shot ${s.number} of ${shots.length}`;
    document.getElementById('preview-title').textContent = s.title || `Shot ${s.number}`;
    document.getElementById('preview-desc').textContent = s.description || 'No description';
    document.getElementById('preview-camera').textContent = s.camera ? `📷 ${s.camera}` : '';

    document.getElementById('preview-shot-info').textContent = `Shot ${previewIndex + 1} of ${shots.length}`;
    document.getElementById('preview-prev').disabled = previewIndex <= 0;
    document.getElementById('preview-next').disabled = previewIndex >= shots.length - 1;
    updatePreviewProgress();
  }

  function updatePreviewProgress() {
    if (!currentProject || !currentProject.shots.length) {
      document.getElementById('preview-progress-bar').style.width = '0%';
      document.getElementById('preview-time').textContent = '0:00 / 0:00';
      return;
    }
    const shots = currentProject.shots;
    const total = getTotalDuration(shots);
    let elapsed = 0;
    for (let i = 0; i < previewIndex; i++) elapsed += Number(shots[i].duration) || 0;
    elapsed += previewElapsedInShot;
    const pct = total > 0 ? Math.min(100, (elapsed / total) * 100) : 0;
    document.getElementById('preview-progress-bar').style.width = pct + '%';
    document.getElementById('preview-time').textContent = `${formatClock(elapsed)} / ${formatClock(total)}`;
  }

  function stopPreview() {
    previewPlaying = false;
    if (previewTimer) clearTimeout(previewTimer);
    previewTimer = null;
    if (previewRaf) cancelAnimationFrame(previewRaf);
    previewRaf = null;
    const btn = document.getElementById('preview-play');
    if (btn) btn.textContent = '▶ Play';
  }

  function playFromCurrent() {
    if (!currentProject || !currentProject.shots.length) {
      showToast('Add shots first');
      return;
    }
    previewPlaying = true;
    document.getElementById('preview-play').textContent = '⏸ Pause';
    showPreviewShot(previewIndex);

    const tick = () => {
      if (!previewPlaying) return;
      const shots = currentProject.shots;
      const shot = shots[previewIndex];
      const dur = Number(shot.duration) || 1;
      previewElapsedInShot += 0.1;
      updatePreviewProgress();

      if (previewElapsedInShot >= dur) {
        previewElapsedInShot = 0;
        if (previewIndex < shots.length - 1) {
          previewIndex++;
          showPreviewShot(previewIndex);
          previewTimer = setTimeout(tick, 100);
        } else {
          stopPreview();
          showToast('Preview finished');
        }
      } else {
        previewTimer = setTimeout(tick, 100);
      }
    };
    previewTimer = setTimeout(tick, 100);
  }

  function togglePreview() {
    if (previewPlaying) {
      stopPreview();
    } else {
      if (!currentProject?.shots?.length) {
        showToast('Add shots first');
        return;
      }
      // restart from beginning if at end
      if (previewIndex >= currentProject.shots.length - 1 && previewElapsedInShot > 0) {
        previewIndex = 0;
        previewElapsedInShot = 0;
      }
      playFromCurrent();
    }
  }

  function previewPrev() {
    stopPreview();
    previewElapsedInShot = 0;
    if (previewIndex > 0) showPreviewShot(previewIndex - 1);
  }

  function previewNext() {
    stopPreview();
    previewElapsedInShot = 0;
    if (currentProject && previewIndex < currentProject.shots.length - 1) {
      showPreviewShot(previewIndex + 1);
    }
  }

  function initPreviewTab() {
    stopPreview();
    previewIndex = 0;
    previewElapsedInShot = 0;
    if (!currentProject || !currentProject.shots.length) {
      document.getElementById('preview-placeholder').style.display = 'block';
      document.getElementById('preview-content').style.display = 'none';
      document.getElementById('preview-progress-bar').style.width = '0%';
      document.getElementById('preview-time').textContent = '0:00 / 0:00';
      document.getElementById('preview-shot-info').textContent = 'Shot 0 of 0';
      document.getElementById('preview-prev').disabled = true;
      document.getElementById('preview-next').disabled = true;
      document.getElementById('preview-play').textContent = '▶ Play';
      return;
    }
    showPreviewShot(0);
  }

  // ---------- UI Helpers ----------
  function showView(name) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    const view = document.getElementById('view-' + name);
    if (view) view.classList.add('active');
    const nav = document.querySelector(`.nav-btn[data-view="${name}"]`);
    if (nav) nav.classList.add('active');
    if (name === 'library') renderLibrary();
    if (name === 'studio' && currentProject) renderStudio();
  }

  function switchTab(tabName) {
    // stop preview when leaving the tab
    if (tabName !== 'preview') stopPreview();
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelector(`.tab[data-tab="${tabName}"]`)?.classList.add('active');
    document.getElementById('tab-' + tabName)?.classList.add('active');
    if (tabName === 'prompts') refreshPrompts();
    if (tabName === 'timeline') renderTimeline();
    if (tabName === 'preview') initPreviewTab();
  }

  function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.style.display = 'block';
    clearTimeout(t._timer);
    t._timer = setTimeout(() => { t.style.display = 'none'; }, 2400);
  }

  function copyText(text) {
    navigator.clipboard.writeText(text).then(() => showToast('Copied to clipboard'));
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function escapeForAttr(str) {
    return escapeHtml(str).replace(/`/g, '\\`').replace(/\$/g, '\\$');
  }

  // ---------- Theme ----------
  function toggleTheme() {
    const html = document.documentElement;
    const next = html.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
    html.setAttribute('data-theme', next);
    localStorage.setItem('naeem_theme', next);
  }

  function initTheme() {
    const saved = localStorage.getItem('naeem_theme');
    if (saved) document.documentElement.setAttribute('data-theme', saved);
  }

  // ---------- Init ----------
  function init() {
    loadProjects();
    initTheme();

    // Nav
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.addEventListener('click', () => showView(btn.dataset.view));
    });

    // Tabs
    document.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    document.getElementById('new-project-btn').addEventListener('click', createProject);
    document.getElementById('theme-toggle').addEventListener('click', toggleTheme);

    // Auto-save title etc on blur
    ['project-title', 'project-style', 'project-aspect'].forEach(id => {
      document.getElementById(id)?.addEventListener('change', () => {
        if (currentProject) saveProject();
      });
    });

    showView('home');

    // If encrypted store is locked, gently prompt unlock
    if (encryptionEnabled && !cryptoKey) {
      setTimeout(() => {
        showToast('Projects are encrypted — unlock via 🔒');
      }, 600);
    }
  }

  function openSecurityModal() {
    const modal = document.getElementById('modal-security');
    const status = document.getElementById('sec-status');
    const enablePanel = document.getElementById('sec-enable-panel');
    const unlockPanel = document.getElementById('sec-unlock-panel');
    const changePanel = document.getElementById('sec-change-panel');
    const actionBtn = document.getElementById('sec-action-btn');

    enablePanel.style.display = 'none';
    unlockPanel.style.display = 'none';
    changePanel.style.display = 'none';

    if (encryptionEnabled && !cryptoKey) {
      status.textContent = 'Encrypted store detected — unlock required.';
      unlockPanel.style.display = 'block';
      actionBtn.textContent = 'Unlock';
      actionBtn.dataset.mode = 'unlock';
    } else if (encryptionEnabled && cryptoKey) {
      status.textContent = 'Encryption active. You can rotate the passphrase (new salt + key derived).';
      changePanel.style.display = 'block';
      actionBtn.textContent = 'Change Passphrase';
      actionBtn.dataset.mode = 'change';
    } else {
      status.textContent = 'Encryption is off. Enable to protect projects at rest.';
      enablePanel.style.display = 'block';
      actionBtn.textContent = 'Enable Encryption';
      actionBtn.dataset.mode = 'enable';
    }
    modal.style.display = 'flex';
  }

  function closeSecurityModal() {
    document.getElementById('modal-security').style.display = 'none';
  }

  async function handleSecurityAction() {
    const mode = document.getElementById('sec-action-btn').dataset.mode;
    if (mode === 'enable') {
      const p1 = document.getElementById('sec-pass').value;
      const p2 = document.getElementById('sec-pass-confirm').value;
      if (p1 !== p2) {
        showToast('Passphrases do not match');
        return;
      }
      const ok = await enableEncryption(p1);
      if (ok) {
        closeSecurityModal();
        renderLibrary();
      }
    } else if (mode === 'unlock') {
      const p = document.getElementById('sec-unlock-pass').value;
      const ok = await unlockWithPassphrase(p);
      if (ok) {
        showToast('Unlocked');
        closeSecurityModal();
        renderLibrary();
      } else {
        showToast('Incorrect passphrase');
      }
    } else if (mode === 'change') {
      const oldP = document.getElementById('sec-old-pass').value;
      const newP = document.getElementById('sec-new-pass').value;
      const ok = await changePassphrase(oldP, newP);
      if (ok) closeSecurityModal();
    }
  }

  // Public API
  return {
    init,
    showView,
    createProject,
    openProject,
    deleteProject,
    saveProject,
    exportProject,
    addCharacter,
    editCharacter,
    saveCharacter,
    removeCharacter,
    closeModal,
    addShot,
    removeShot,
    updateShot,
    generateStructure,
    refreshPrompts,
    copyText,
    enableEncryption,
    changePassphrase,
    unlockWithPassphrase,
    openSecurityModal,
    closeSecurityModal,
    handleSecurityAction,
    isEncryptionEnabled: () => encryptionEnabled,
    isUnlocked: () => !!cryptoKey,
    downloadJSON,
    downloadPrompts,
    downloadCSV,
    downloadStoryboard,
    togglePreview,
    previewPrev,
    previewNext
  };
})();

document.addEventListener('DOMContentLoaded', App.init);
